package work.hamid.interview.domain;

public abstract class AbstractParams {

    protected String site = "stackoverflow";

    public abstract String toQueryParams();
}
