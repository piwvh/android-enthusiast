package work.hamid.interview.exception;

public class NotFoundException extends RuntimeException {
}
